using System;

namespace sampleConApp
{
    class Ex05ArrayMach{
        //create the instance of the Machine Database
        //call the methods of the machine database
        //display the appropriate outputs
    }
}