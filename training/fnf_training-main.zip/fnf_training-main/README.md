Day 1 : Basics, Enum , Class And Object , Array
